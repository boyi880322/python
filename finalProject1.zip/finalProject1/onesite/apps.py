from django.apps import AppConfig


class OnesiteConfig(AppConfig):
    name = 'onesite'
